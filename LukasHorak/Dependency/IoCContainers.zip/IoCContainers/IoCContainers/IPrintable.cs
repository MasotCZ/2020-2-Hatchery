﻿namespace IoCContainers
{
    public interface IPrintable
    {
        string Print();
    }
}
