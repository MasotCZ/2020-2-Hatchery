﻿namespace IoCContainers
{
    public interface IPrintMachine
    {
        string PrintOnPaper();
    }
}
