﻿namespace IoCContainers
{
    public interface IAuditable
    {
        bool DoAudit();
    }
}
