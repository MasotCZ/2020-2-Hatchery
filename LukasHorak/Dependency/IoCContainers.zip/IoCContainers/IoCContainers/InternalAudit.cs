﻿namespace IoCContainers
{
    public class InternalAudit : IAuditable
    {
        public bool DoAudit()
        {
            return true;
        }
    }
}
