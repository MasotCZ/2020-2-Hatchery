﻿namespace IoCContainers
{
    public class CanonPrinter : IPrintMachine
    {
        public string PrintOnPaper()
        {
            return "Printing on paper :-)";
        }
    }
}
