﻿namespace IoCContainers
{
    public class PdfPrinter : IPrintable
    {
        IPrintMachine _printMachine;

        public PdfPrinter(IPrintMachine printMachine)
        {
            _printMachine = printMachine;
        }
        
        public string Print()
        {
            return _printMachine.PrintOnPaper();
        }
    }
}
