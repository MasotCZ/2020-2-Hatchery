﻿namespace CampWebAPISample.Data;

public interface IDbContextFactory
{
}