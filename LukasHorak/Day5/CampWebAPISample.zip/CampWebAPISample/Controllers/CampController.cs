﻿using Microsoft.AspNetCore.Mvc;

namespace CampWebAPISample.Controllers
{
    [Route("api/[controller]")]
    public class CampController : Controller
    {
      
        public object Get()
        {
            return new { Moniker = "Praha", Name = ".NET Hatchery 2022" };
        }
    }

    
}
